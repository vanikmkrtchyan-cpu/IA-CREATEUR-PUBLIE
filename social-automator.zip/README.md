# Social Automator - Python

Génère automatiquement du contenu (texte + image) et publie sur Instagram / LinkedIn.

## Installation rapide
1. Copier `.env.example` -> `.env` et remplir les valeurs.
2. Créer un venv et installer : `pip install -r requirements.txt`
3. Lancer : `python -m src.run_scheduler`

## Notes
- Instagram requiert un compte Business/Creator relié à une Page Facebook.
- LinkedIn requiert les bons scopes API (w_member_social).
- Les logs sont dans `logs/posts.log`.
