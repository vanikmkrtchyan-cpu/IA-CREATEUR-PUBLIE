import requests
from .config import Config

GRAPH_BASE = "https://graph.facebook.com/v16.0"

def create_instagram_media(ig_user_id, image_url, caption, access_token):
    url = f"{GRAPH_BASE}/{ig_user_id}/media"
    payload = {
        "image_url": image_url,
        "caption": caption,
        "access_token": access_token
    }
    r = requests.post(url, data=payload, timeout=30)
    r.raise_for_status()
    return r.json().get("id")

def publish_instagram_media(ig_user_id, creation_id, access_token):
    url = f"{GRAPH_BASE}/{ig_user_id}/media_publish"
    payload = {"creation_id": creation_id, "access_token": access_token}
    r = requests.post(url, data=payload, timeout=30)
    r.raise_for_status()
    return r.json()

def post_image_to_instagram(image_url, caption):
    creation_id = create_instagram_media(Config.IG_USER_ID, image_url, caption, Config.IG_PAGE_ACCESS_TOKEN)
    return publish_instagram_media(Config.IG_USER_ID, creation_id, Config.IG_PAGE_ACCESS_TOKEN)
