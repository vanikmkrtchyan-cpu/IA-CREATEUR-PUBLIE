import boto3
from botocore.client import Config as BotoConfig
from .config import Config

def s3_client():
    return boto3.client(
        "s3",
        aws_access_key_id=Config.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=Config.AWS_SECRET_ACCESS_KEY,
        region_name=Config.S3_REGION,
        config=BotoConfig(signature_version='s3v4')
    )

def upload_public_file(local_path, key_name):
    client = s3_client()
    bucket = Config.S3_BUCKET_NAME
    extra_args = {"ACL": "public-read", "ContentType": "image/png"}
    client.upload_file(local_path, bucket, key_name, ExtraArgs=extra_args)
    url = f"https://{bucket}.s3.{Config.S3_REGION}.amazonaws.com/{key_name}"
    return url
