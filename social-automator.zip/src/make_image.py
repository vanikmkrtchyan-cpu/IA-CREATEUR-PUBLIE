from PIL import Image, ImageDraw, ImageFont
from datetime import datetime

def make_image_with_text(title, subtitle=None, filename=None, size=(1080,1080), bg=(255,255,255)):
    if filename is None:
        filename = f"out_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.png"
    img = Image.new("RGB", size, color=bg)
    draw = ImageDraw.Draw(img)

    try:
        font_title = ImageFont.truetype("DejaVuSans-Bold.ttf", 64)
        font_sub = ImageFont.truetype("DejaVuSans.ttf", 36)
    except Exception:
        font_title = ImageFont.load_default()
        font_sub = ImageFont.load_default()

    padding = 60
    draw.text((padding, padding), title, font=font_title, fill=(0,0,0))
    if subtitle:
        draw.text((padding, padding+140), subtitle, font=font_sub, fill=(80,80,80))

    img.save(filename)
    return filename
