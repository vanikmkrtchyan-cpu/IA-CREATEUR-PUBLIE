import logging
import os
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime

from .generate_text import generate_caption
from .make_image import make_image_with_text
from .storage_s3 import upload_public_file
from .instagram_publish import post_image_to_instagram
from .linkedin_publish import linkedin_text_post
from .config import Config

LOGFILE = os.path.join(os.path.dirname(__file__), "..", "logs", "posts.log")
os.makedirs(os.path.dirname(LOGFILE), exist_ok=True)
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

def job_post_daily():
    try:
        context = "Conseils rapides : comment améliorer la composition photo sur smartphone."
        caption = generate_caption(context, tone=Config.DEFAULT_TEXT_TONE, hashtags_count=5)
        img_file = make_image_with_text("Conseils Photo", "3 astuces simples")
        key = f"posts/{os.path.basename(img_file)}"
        public_url = upload_public_file(img_file, key)
        ig_resp = post_image_to_instagram(public_url, caption)
        li_resp = linkedin_text_post(caption)
        logging.info(f"Posted IG: {ig_resp} | LI: {li_resp}")
        print("Post effectué:", datetime.utcnow())
    except Exception as e:
        logging.exception("Erreur lors du job de publication: %s", e)
        print("Erreur:", e)

def start_scheduler():
    sched = BackgroundScheduler()
    sched.add_job(job_post_daily, 'cron', hour=9, minute=0)
    sched.start()
    print("Scheduler démarré — job programmé à 09:00 UTC chaque jour.")
    return sched
