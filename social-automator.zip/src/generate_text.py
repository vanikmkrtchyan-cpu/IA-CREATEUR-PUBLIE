import openai
from .config import Config
openai.api_key = Config.OPENAI_API_KEY

def generate_caption(context, tone=None, hashtags_count=5, max_tokens=200):
    tone = tone or Config.DEFAULT_TEXT_TONE
    prompt = (
        f"Écris une légende pour un post Instagram/LinkedIn.\n"
        f"Contexte : {context}\n"
        f"Ton : {tone}\n"
        f"Inclus {hashtags_count} hashtags pertinents à la fin.\n"
        "Sois concis, engageant et termine par un CTA court."
    )
    resp = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=max_tokens,
        temperature=0.7
    )
    return resp.choices[0].message.content.strip()
